
  # GestiON Web App UI Design

  This is a code bundle for GestiON Web App UI Design. The original project is available at https://www.figma.com/design/jdAuQtQViasT1zKHmEZ5Tv/GestiON-Web-App-UI-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  