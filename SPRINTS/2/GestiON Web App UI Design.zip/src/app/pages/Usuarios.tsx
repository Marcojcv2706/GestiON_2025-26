import { Card, CardContent, CardHeader, CardTitle, Button, Input, Table, TableBody, TableCell, TableHead, TableHeader, TableRow, Badge } from "../components/ui/ui";
import { Plus, Search, Shield, UserCog, Users } from "lucide-react";

export function Usuarios() {
  const users = [
    { id: 1, name: "Admin ISAM", email: "admin@isam.edu.ar", role: "Administrador", status: "Activo", lastLogin: "Hoy, 08:30" },
    { id: 2, name: "Carlos Martínez", email: "cmartinez@isam.edu.ar", role: "Docente", status: "Activo", lastLogin: "Ayer, 14:15" },
    { id: 3, name: "Laura Gómez", email: "lgomez@isam.edu.ar", role: "Estudiante", status: "Activo", lastLogin: "20/10/2023" },
    { id: 4, name: "Sofía Ramírez", email: "sramirez@isam.edu.ar", role: "Docente", status: "Inactivo", lastLogin: "01/09/2023" },
  ];

  return (
    <div className="flex flex-col xl:flex-row gap-6">
      {/* Main Area */}
      <div className="flex-1 space-y-6">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <div>
            <h1 className="text-2xl font-bold text-[#1e3a5f]">Gestión de Usuarios</h1>
            <p className="text-slate-500">Panel de administración de cuentas y roles.</p>
          </div>
          <Button>
            <Plus className="w-4 h-4 mr-2" />
            Nuevo Usuario
          </Button>
        </div>

        <Card>
          <CardHeader className="py-4 flex flex-row items-center justify-between">
            <div className="relative w-full max-w-sm">
              <Search className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
              <Input placeholder="Buscar por nombre o email..." className="pl-9 h-9" />
            </div>
            <div className="hidden sm:flex gap-2">
              <select className="h-9 rounded-lg border border-slate-300 bg-white px-3 text-sm text-slate-600 focus:outline-none focus:ring-2 focus:ring-[#4a9eff]">
                <option>Todos los roles</option>
                <option>Administrador</option>
                <option>Docente</option>
                <option>Estudiante</option>
              </select>
            </div>
          </CardHeader>
          <CardContent className="p-0">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Nombre</TableHead>
                  <TableHead>Rol</TableHead>
                  <TableHead>Estado</TableHead>
                  <TableHead>Último Acceso</TableHead>
                  <TableHead className="text-right">Acciones</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {users.map((user) => (
                  <TableRow key={user.id}>
                    <TableCell>
                      <div className="flex flex-col">
                        <span className="font-semibold text-slate-800">{user.name}</span>
                        <span className="text-xs text-slate-500">{user.email}</span>
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge variant={user.role === 'Administrador' ? 'blue' : user.role === 'Docente' ? 'green' : 'gray'}>
                        {user.role}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <Badge variant={user.status === 'Activo' ? 'green' : 'red'}>
                        {user.status}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-sm text-slate-500">{user.lastLogin}</TableCell>
                    <TableCell className="text-right">
                      <Button variant="ghost" className="h-8 w-8 p-0">
                        <UserCog className="w-4 h-4 text-slate-500" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>

      {/* Stats Sidebar */}
      <div className="w-full xl:w-72 shrink-0 space-y-6">
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Resumen de Usuarios</CardTitle>
          </CardHeader>
          <CardContent className="p-4 space-y-4">
            <div className="flex items-center justify-between p-3 bg-blue-50 rounded-lg">
              <div className="flex items-center gap-3">
                <Users className="w-5 h-5 text-blue-500" />
                <span className="font-medium text-slate-700">Total</span>
              </div>
              <span className="font-bold text-xl text-blue-700">452</span>
            </div>
            
            <div className="flex items-center justify-between p-3 bg-emerald-50 rounded-lg">
              <div className="flex items-center gap-3">
                <Shield className="w-5 h-5 text-emerald-500" />
                <span className="font-medium text-slate-700">Docentes</span>
              </div>
              <span className="font-bold text-xl text-emerald-700">48</span>
            </div>

            <div className="flex items-center justify-between p-3 bg-slate-50 rounded-lg">
              <div className="flex items-center gap-3">
                <Users className="w-5 h-5 text-slate-500" />
                <span className="font-medium text-slate-700">Estudiantes</span>
              </div>
              <span className="font-bold text-xl text-slate-700">398</span>
            </div>
            
            <div className="flex items-center justify-between p-3 bg-purple-50 rounded-lg">
              <div className="flex items-center gap-3">
                <Shield className="w-5 h-5 text-purple-500" />
                <span className="font-medium text-slate-700">Admins</span>
              </div>
              <span className="font-bold text-xl text-purple-700">6</span>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
