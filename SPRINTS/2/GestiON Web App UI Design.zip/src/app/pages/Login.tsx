import { useNavigate } from "react-router";
import { Button, Card, CardContent, Input, Label } from "../components/ui/ui";
import { Lock, Mail } from "lucide-react";

export function Login() {
  const navigate = useNavigate();

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    navigate("/app");
  };

  return (
    <div className="min-h-screen bg-[#f4f6fb] flex items-center justify-center p-4 font-sans">
      <Card className="w-full max-w-md">
        <CardContent className="pt-8 pb-8 px-8 flex flex-col items-center">
          <div className="w-16 h-16 bg-[#1e3a5f] rounded-2xl flex items-center justify-center text-white font-bold text-3xl mb-6 shadow-lg shadow-[#1e3a5f]/20">
            <span className="text-[#4a9eff]">G</span>
          </div>
          <h1 className="text-2xl font-bold text-slate-800 mb-2">GestiON</h1>
          <p className="text-slate-500 mb-8 text-center text-sm">
            Sistema de Gestión Institucional <br/> Instituto Superior Adventista de Misiones
          </p>

          <form onSubmit={handleLogin} className="w-full space-y-5">
            <div>
              <Label htmlFor="email">Correo Electrónico</Label>
              <div className="relative">
                <Mail className="absolute left-3 top-2.5 h-5 w-5 text-slate-400" />
                <Input id="email" type="email" placeholder="usuario@isam.edu.ar" className="pl-10" required />
              </div>
            </div>
            <div>
              <Label htmlFor="password">Contraseña</Label>
              <div className="relative">
                <Lock className="absolute left-3 top-2.5 h-5 w-5 text-slate-400" />
                <Input id="password" type="password" placeholder="••••••••" className="pl-10" required />
              </div>
            </div>
            
            <div className="flex items-center justify-between text-sm mt-2 mb-6">
              <label className="flex items-center gap-2 text-slate-600">
                <input type="checkbox" className="rounded border-slate-300 text-[#4a9eff] focus:ring-[#4a9eff]" />
                Recordarme
              </label>
              <a href="#" className="text-[#4a9eff] hover:underline font-medium">¿Olvidaste tu contraseña?</a>
            </div>

            <Button type="submit" className="w-full h-11 text-base">
              Ingresar al Sistema
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
