import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle, Button, Input, Label, Badge } from "../components/ui/ui";
import { CalendarDays, Clock, MapPin, Plus, Search, User } from "lucide-react";
import { toast } from "sonner";

export function Eventos() {
  const [isCreating, setIsCreating] = useState(false);

  const spaces = ["Salón de Actos", "SUM", "Pabellón de Música"];
  const [selectedSpace, setSelectedSpace] = useState("Todos");

  const events = [
    { id: 1, title: "Ensayo Coro", space: "Pabellón de Música", date: "24 Oct 2023", time: "14:00 - 16:00", user: "Prof. Martínez", status: "Confirmado" },
    { id: 2, title: "Reunión de Personal", space: "Salón de Actos", date: "24 Oct 2023", time: "16:30 - 18:00", user: "Admin", status: "Confirmado" },
    { id: 3, title: "Clase Magistral", space: "SUM", date: "24 Oct 2023", time: "18:30 - 20:30", user: "Prof. Gómez", status: "Pendiente" },
    { id: 4, title: "Acto Patrio", space: "Salón de Actos", date: "25 Oct 2023", time: "09:00 - 12:00", user: "Dirección", status: "Confirmado" },
  ];

  const handleCreateEvent = (e: React.FormEvent) => {
    e.preventDefault();
    toast.success("Evento creado exitosamente");
    setIsCreating(false);
  };

  return (
    <div className="flex h-full gap-6">
      {/* Main Calendar/List Area */}
      <div className={`flex-1 flex flex-col space-y-4 ${isCreating ? 'hidden xl:flex' : 'flex'}`}>
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <div>
            <h1 className="text-2xl font-bold text-[#1e3a5f]">Eventos y Turnos</h1>
            <p className="text-slate-500">Gestión de reservas de espacios.</p>
          </div>
          <Button onClick={() => setIsCreating(true)} className="shrink-0">
            <Plus className="w-4 h-4 mr-2" />
            Nuevo Evento
          </Button>
        </div>

        <Card className="flex-1 flex flex-col overflow-hidden">
          <CardHeader className="bg-slate-50/50 py-3">
            <div className="flex flex-col md:flex-row justify-between items-center w-full gap-4">
              <div className="flex gap-2 w-full md:w-auto overflow-x-auto pb-2 md:pb-0 hide-scrollbar">
                <button 
                  onClick={() => setSelectedSpace("Todos")}
                  className={`px-4 py-2 rounded-full text-sm font-medium whitespace-nowrap transition-colors ${selectedSpace === "Todos" ? "bg-[#1e3a5f] text-white" : "bg-white text-slate-600 hover:bg-slate-100 border border-slate-200"}`}
                >
                  Todos los espacios
                </button>
                {spaces.map(space => (
                  <button 
                    key={space}
                    onClick={() => setSelectedSpace(space)}
                    className={`px-4 py-2 rounded-full text-sm font-medium whitespace-nowrap transition-colors ${selectedSpace === space ? "bg-[#1e3a5f] text-white" : "bg-white text-slate-600 hover:bg-slate-100 border border-slate-200"}`}
                  >
                    {space}
                  </button>
                ))}
              </div>
              <div className="relative w-full md:w-64">
                <Search className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
                <Input placeholder="Buscar evento..." className="pl-9 h-9" />
              </div>
            </div>
          </CardHeader>
          <div className="flex-1 overflow-auto p-4 md:p-6">
            <div className="space-y-4">
              {events.filter(e => selectedSpace === "Todos" || e.space === selectedSpace).map(event => (
                <div key={event.id} className="border border-slate-200 rounded-xl p-4 hover:shadow-md transition-shadow bg-white flex flex-col md:flex-row md:items-center justify-between gap-4">
                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 rounded-xl bg-[#4a9eff]/10 flex items-center justify-center text-[#4a9eff] shrink-0">
                      <span className="font-bold text-lg">{event.date.split(' ')[0]}</span>
                    </div>
                    <div>
                      <h4 className="font-semibold text-slate-800 text-lg">{event.title}</h4>
                      <div className="flex flex-wrap gap-x-4 gap-y-2 mt-2 text-sm text-slate-500">
                        <span className="flex items-center gap-1.5">
                          <MapPin className="w-4 h-4" /> {event.space}
                        </span>
                        <span className="flex items-center gap-1.5">
                          <Clock className="w-4 h-4" /> {event.time}
                        </span>
                        <span className="flex items-center gap-1.5">
                          <User className="w-4 h-4" /> {event.user}
                        </span>
                      </div>
                    </div>
                  </div>
                  <div className="flex md:flex-col items-center md:items-end justify-between md:justify-center gap-2">
                    <Badge variant={event.status === 'Confirmado' ? 'green' : 'yellow'}>{event.status}</Badge>
                    <Button variant="ghost" className="h-8 px-2 text-xs">Ver detalles</Button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </Card>
      </div>

      {/* Right Side Panel - Create Event */}
      {isCreating && (
        <Card className="w-full xl:w-[400px] shrink-0 flex flex-col overflow-hidden h-full">
          <CardHeader>
            <CardTitle>Reservar Espacio</CardTitle>
            <Button variant="ghost" className="h-8 w-8 p-0" onClick={() => setIsCreating(false)}>
              X
            </Button>
          </CardHeader>
          <div className="flex-1 overflow-y-auto p-6">
            <form onSubmit={handleCreateEvent} className="space-y-5">
              <div>
                <Label>Nombre de la Actividad</Label>
                <Input placeholder="Ej: Ensayo General" required />
              </div>
              
              <div>
                <Label>Espacio a Reservar</Label>
                <select className="flex h-10 w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-[#4a9eff] focus:border-transparent">
                  <option value="">Seleccionar espacio...</option>
                  {spaces.map(s => <option key={s} value={s}>{s}</option>)}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>Fecha</Label>
                  <Input type="date" required />
                </div>
                <div>
                  <Label>Capacidad Est.</Label>
                  <Input type="number" placeholder="Ej: 50" />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>Hora Inicio</Label>
                  <Input type="time" required />
                </div>
                <div>
                  <Label>Hora Fin</Label>
                  <Input type="time" required />
                </div>
              </div>

              <div>
                <Label>Responsable / Docente</Label>
                <Input placeholder="Nombre del responsable" required />
              </div>

              <div>
                <Label>Notas Adicionales</Label>
                <textarea 
                  className="flex w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-[#4a9eff] focus:border-transparent min-h-[100px] resize-none"
                  placeholder="Requerimientos especiales..."
                />
              </div>

              <div className="pt-4 flex gap-3">
                <Button type="button" variant="secondary" className="flex-1" onClick={() => setIsCreating(false)}>Cancelar</Button>
                <Button type="submit" className="flex-1">Confirmar Reserva</Button>
              </div>
            </form>
          </div>
        </Card>
      )}
    </div>
  );
}
