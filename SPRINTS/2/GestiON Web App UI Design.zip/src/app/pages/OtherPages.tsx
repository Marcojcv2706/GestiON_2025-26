import { Card, CardContent, CardHeader, CardTitle } from "../components/ui/ui";

export function Historial() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-[#1e3a5f]">Historial General</h1>
        <p className="text-slate-500">Registro de todas las actividades del sistema.</p>
      </div>
      <Card>
        <CardContent className="p-12 text-center text-slate-500">
          <p>La vista de historial está en desarrollo.</p>
        </CardContent>
      </Card>
    </div>
  );
}

export function Perfil() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-[#1e3a5f]">Mi Perfil</h1>
        <p className="text-slate-500">Configuración de cuenta personal.</p>
      </div>
      <Card className="max-w-xl">
        <CardContent className="p-6">
          <div className="flex items-center gap-6 mb-8">
            <div className="w-20 h-20 bg-[#1e3a5f] rounded-full flex items-center justify-center text-white text-2xl font-bold">
              AD
            </div>
            <div>
              <h2 className="text-xl font-bold text-slate-800">Admin ISAM</h2>
              <p className="text-slate-500">Administrador del Sistema</p>
            </div>
          </div>
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Correo Electrónico</label>
              <input disabled value="admin@isam.edu.ar" className="flex h-10 w-full rounded-lg border border-slate-300 bg-slate-50 px-3 py-2 text-sm text-slate-500" />
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
