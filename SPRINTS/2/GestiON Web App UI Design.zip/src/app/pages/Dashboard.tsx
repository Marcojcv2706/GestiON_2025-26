import { Card, CardContent, CardHeader, CardTitle, Badge } from "../components/ui/ui";
import { Users, CalendarDays, Box, ArrowRight, Bell } from "lucide-react";

export function Dashboard() {
  const stats = [
    { label: "Eventos Hoy", value: "3", icon: CalendarDays, color: "text-[#4a9eff]", bg: "bg-[#4a9eff]/10" },
    { label: "Espacios Disponibles", value: "1", icon: Users, color: "text-emerald-500", bg: "bg-emerald-500/10" },
    { label: "Préstamos Activos", value: "12", icon: Box, color: "text-amber-500", bg: "bg-amber-500/10" },
  ];

  const upcomingEvents = [
    { id: 1, title: "Ensayo Coro", space: "Pabellón de Música", time: "14:00 - 16:00", status: "Confirmado" },
    { id: 2, title: "Reunión de Personal", space: "Salón de Actos", time: "16:30 - 18:00", status: "Confirmado" },
    { id: 3, title: "Clase Magistral", space: "SUM", time: "18:30 - 20:30", status: "Pendiente" },
  ];

  const notifications = [
    { id: 1, text: "Nuevo equipo añadido al inventario: Proyector Epson", time: "Hace 10 min" },
    { id: 2, text: "Juan Pérez solicitó un teclado para las 15:00", time: "Hace 1 hora" },
    { id: 3, text: "Recordatorio: El SUM estará en mantenimiento mañana", time: "Hace 3 horas" },
  ];

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-[#1e3a5f]">Dashboard</h1>
          <p className="text-slate-500">Bienvenido al sistema GestiON. Aquí tienes un resumen de hoy.</p>
        </div>
        <div className="flex gap-2">
          <Badge variant="blue" className="px-3 py-1 text-sm">Rol: Administrador</Badge>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {stats.map((stat, i) => {
          const Icon = stat.icon;
          return (
            <Card key={i}>
              <CardContent className="p-6 flex items-center gap-4">
                <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${stat.bg} ${stat.color}`}>
                  <Icon className="w-6 h-6" />
                </div>
                <div>
                  <p className="text-sm font-medium text-slate-500">{stat.label}</p>
                  <p className="text-2xl font-bold text-slate-800">{stat.value}</p>
                </div>
              </CardContent>
            </Card>
          )
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Upcoming Events */}
        <Card className="col-span-1 lg:col-span-2">
          <CardHeader>
            <CardTitle>Eventos Próximos</CardTitle>
            <button className="text-sm font-medium text-[#4a9eff] flex items-center gap-1 hover:underline">
              Ver calendario <ArrowRight className="w-4 h-4" />
            </button>
          </CardHeader>
          <CardContent className="p-0">
            <div className="divide-y divide-slate-100">
              {upcomingEvents.map(event => (
                <div key={event.id} className="p-4 md:p-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4 hover:bg-slate-50/50 transition-colors">
                  <div className="flex items-start gap-4">
                    <div className="w-10 h-10 rounded-lg bg-slate-100 flex items-center justify-center text-slate-500 shrink-0">
                      <CalendarDays className="w-5 h-5" />
                    </div>
                    <div>
                      <h4 className="font-semibold text-slate-800">{event.title}</h4>
                      <p className="text-sm text-slate-500 flex items-center gap-2 mt-1">
                        <span className="w-2 h-2 rounded-full bg-[#1e3a5f]"></span>
                        {event.space}
                      </p>
                    </div>
                  </div>
                  <div className="flex sm:flex-col items-center sm:items-end justify-between sm:justify-center gap-2 w-full sm:w-auto mt-2 sm:mt-0">
                    <span className="text-sm font-medium text-slate-700">{event.time}</span>
                    <Badge variant={event.status === 'Confirmado' ? 'green' : 'yellow'}>
                      {event.status}
                    </Badge>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Notifications */}
        <Card className="col-span-1">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Bell className="w-5 h-5 text-slate-400" />
              Notificaciones
            </CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            <div className="divide-y divide-slate-100">
              {notifications.map(notif => (
                <div key={notif.id} className="p-4 md:p-6 hover:bg-slate-50/50 transition-colors">
                  <p className="text-sm text-slate-700 mb-2 leading-relaxed">{notif.text}</p>
                  <p className="text-xs text-slate-400">{notif.time}</p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
