import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle, Button, Input, Table, TableBody, TableCell, TableHead, TableHeader, TableRow, Badge } from "../components/ui/ui";
import { Plus, Search, Filter } from "lucide-react";

export function Implementos() {
  const [activeTab, setActiveTab] = useState<'inventario' | 'prestamos'>('inventario');

  const inventory = [
    { id: "EQ-001", name: "Proyector Epson WXGA", category: "Audiovisual", stock: 3, available: 2, status: "Bueno" },
    { id: "EQ-002", name: "Micrófono Inalámbrico Shure", category: "Audio", stock: 5, available: 1, status: "Bueno" },
    { id: "EQ-003", name: "Teclado Yamaha", category: "Música", stock: 2, available: 0, status: "En uso" },
    { id: "EQ-004", name: "Alargue 10m", category: "Accesorios", stock: 10, available: 8, status: "Bueno" },
    { id: "EQ-005", name: "Parlante Potenciado", category: "Audio", stock: 4, available: 3, status: "Mantenimiento" },
  ];

  const loans = [
    { id: "L-101", user: "Martín Gómez", item: "Micrófono Inalámbrico Shure", dateOut: "24/10/23", dateIn: "24/10/23 18:00", status: "Activo" },
    { id: "L-102", user: "Lucía Pérez", item: "Teclado Yamaha", dateOut: "23/10/23", dateIn: "23/10/23 20:00", status: "Atrasado" },
    { id: "L-103", user: "Prof. Ramírez", item: "Proyector Epson WXGA", dateOut: "24/10/23", dateIn: "24/10/23 12:00", status: "Devuelto" },
  ];

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold text-[#1e3a5f]">Implementos y Préstamos</h1>
          <p className="text-slate-500">Inventario de equipos y control de préstamos a estudiantes y docentes.</p>
        </div>
        <div className="flex gap-3">
          <Button variant="secondary" className="bg-white">
            <Filter className="w-4 h-4 mr-2" />
            Filtrar
          </Button>
          <Button>
            <Plus className="w-4 h-4 mr-2" />
            {activeTab === 'inventario' ? 'Nuevo Equipo' : 'Nuevo Préstamo'}
          </Button>
        </div>
      </div>

      <div className="flex gap-4 border-b border-slate-200">
        <button 
          onClick={() => setActiveTab('inventario')}
          className={`pb-3 px-1 text-sm font-medium transition-colors border-b-2 ${activeTab === 'inventario' ? 'border-[#4a9eff] text-[#1e3a5f]' : 'border-transparent text-slate-500 hover:text-slate-700'}`}
        >
          Inventario
        </button>
        <button 
          onClick={() => setActiveTab('prestamos')}
          className={`pb-3 px-1 text-sm font-medium transition-colors border-b-2 ${activeTab === 'prestamos' ? 'border-[#4a9eff] text-[#1e3a5f]' : 'border-transparent text-slate-500 hover:text-slate-700'}`}
        >
          Préstamos Activos e Historial
        </button>
      </div>

      <Card>
        <CardHeader className="py-4">
          <div className="relative w-full max-w-sm">
            <Search className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
            <Input placeholder={`Buscar en ${activeTab}...`} className="pl-9 h-9" />
          </div>
        </CardHeader>
        <CardContent className="p-0">
          {activeTab === 'inventario' ? (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Código</TableHead>
                  <TableHead>Nombre del Equipo</TableHead>
                  <TableHead>Categoría</TableHead>
                  <TableHead className="text-center">Stock Total</TableHead>
                  <TableHead className="text-center">Disponibles</TableHead>
                  <TableHead>Estado</TableHead>
                  <TableHead className="text-right">Acciones</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {inventory.map((item) => (
                  <TableRow key={item.id}>
                    <TableCell className="font-medium text-slate-600">{item.id}</TableCell>
                    <TableCell className="font-semibold text-slate-800">{item.name}</TableCell>
                    <TableCell>{item.category}</TableCell>
                    <TableCell className="text-center">{item.stock}</TableCell>
                    <TableCell className="text-center font-bold text-[#4a9eff]">{item.available}</TableCell>
                    <TableCell>
                      <Badge variant={item.status === 'Bueno' ? 'green' : item.status === 'En uso' ? 'blue' : 'yellow'}>
                        {item.status}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-right">
                      <Button variant="ghost" className="h-8 text-[#4a9eff]">Prestar</Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>ID</TableHead>
                  <TableHead>Usuario</TableHead>
                  <TableHead>Equipo Prestado</TableHead>
                  <TableHead>Fecha Salida</TableHead>
                  <TableHead>Devolución Esperada</TableHead>
                  <TableHead>Estado</TableHead>
                  <TableHead className="text-right">Acciones</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {loans.map((loan) => (
                  <TableRow key={loan.id}>
                    <TableCell className="font-medium text-slate-600">{loan.id}</TableCell>
                    <TableCell className="font-semibold text-slate-800">{loan.user}</TableCell>
                    <TableCell>{loan.item}</TableCell>
                    <TableCell>{loan.dateOut}</TableCell>
                    <TableCell>{loan.dateIn}</TableCell>
                    <TableCell>
                      <Badge variant={loan.status === 'Devuelto' ? 'green' : loan.status === 'Activo' ? 'blue' : 'red'}>
                        {loan.status}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-right">
                      {loan.status !== 'Devuelto' && (
                        <Button variant="ghost" className="h-8 text-emerald-600 hover:text-emerald-700 hover:bg-emerald-50">Devolver</Button>
                      )}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
