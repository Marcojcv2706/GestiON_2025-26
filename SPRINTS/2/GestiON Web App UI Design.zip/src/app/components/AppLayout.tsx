import { Outlet, NavLink, useNavigate, useLocation } from "react-router";
import { LayoutDashboard, CalendarDays, Box, History, Users, UserCircle, LogOut, Menu, X } from "lucide-react";
import { useState } from "react";
import { Toaster } from "sonner";

export function AppLayout() {
  const [isMobileOpen, setIsMobileOpen] = useState(false);
  const navigate = useNavigate();
  const location = useLocation();

  const handleLogout = () => {
    navigate("/");
  };

  const navItems = [
    { name: "Dashboard", path: "/app", icon: LayoutDashboard },
    { name: "Eventos", path: "/app/eventos", icon: CalendarDays },
    { name: "Implementos", path: "/app/implementos", icon: Box },
    { name: "Historial", path: "/app/historial", icon: History },
    { name: "Usuarios", path: "/app/usuarios", icon: Users },
    { name: "Perfil", path: "/app/perfil", icon: UserCircle },
  ];

  return (
    <div className="flex h-screen bg-[#f4f6fb] font-sans text-slate-800">
      <Toaster position="top-right" />
      {/* Mobile Sidebar Overlay */}
      {isMobileOpen && (
        <div 
          className="fixed inset-0 bg-black/50 z-40 lg:hidden"
          onClick={() => setIsMobileOpen(false)}
        />
      )}

      {/* Sidebar */}
      <aside className={`
        fixed inset-y-0 left-0 z-50 w-64 bg-[#1e3a5f] text-white flex flex-col transition-transform duration-300 ease-in-out
        lg:relative lg:translate-x-0
        ${isMobileOpen ? 'translate-x-0' : '-translate-x-full'}
      `}>
        <div className="h-16 flex items-center justify-between px-6 border-b border-white/10">
          <div className="text-xl font-bold tracking-wide flex items-center gap-2">
            <div className="w-8 h-8 bg-[#4a9eff] rounded flex items-center justify-center text-white font-bold">G</div>
            GestiON
          </div>
          <button className="lg:hidden text-white/70 hover:text-white" onClick={() => setIsMobileOpen(false)}>
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto py-6 px-3 flex flex-col gap-1">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = location.pathname === item.path || 
                             (item.path !== '/app' && location.pathname.startsWith(item.path));
            return (
              <NavLink
                key={item.name}
                to={item.path}
                onClick={() => setIsMobileOpen(false)}
                className={`
                  flex items-center gap-3 px-3 py-2.5 rounded-lg transition-colors font-medium text-sm
                  ${isActive 
                    ? "bg-[#4a9eff] text-white" 
                    : "text-white/70 hover:bg-white/10 hover:text-white"
                  }
                `}
              >
                <Icon className="w-5 h-5" />
                {item.name}
              </NavLink>
            );
          })}
        </div>

        <div className="p-4 border-t border-white/10">
          <button 
            onClick={handleLogout}
            className="flex items-center gap-3 px-3 py-2.5 rounded-lg transition-colors font-medium text-sm w-full text-white/70 hover:bg-red-500/10 hover:text-red-400"
          >
            <LogOut className="w-5 h-5" />
            Cerrar Sesión
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col overflow-hidden">
        {/* Mobile Header */}
        <header className="h-16 lg:hidden bg-white border-b flex items-center px-4 justify-between shrink-0">
          <div className="text-lg font-bold text-[#1e3a5f]">GestiON</div>
          <button onClick={() => setIsMobileOpen(true)} className="p-2 text-slate-500 hover:text-slate-700">
            <Menu className="w-6 h-6" />
          </button>
        </header>

        <div className="flex-1 overflow-auto p-4 md:p-8">
          <Outlet />
        </div>
      </main>
    </div>
  );
}
