import { createBrowserRouter } from "react-router";
import { AppLayout } from "./components/AppLayout";
import { Login } from "./pages/Login";
import { Dashboard } from "./pages/Dashboard";
import { Eventos } from "./pages/Eventos";
import { Implementos } from "./pages/Implementos";
import { Usuarios } from "./pages/Usuarios";
import { Historial, Perfil } from "./pages/OtherPages";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: Login,
  },
  {
    path: "/app",
    Component: AppLayout,
    children: [
      { index: true, Component: Dashboard },
      { path: "eventos", Component: Eventos },
      { path: "implementos", Component: Implementos },
      { path: "usuarios", Component: Usuarios },
      { path: "historial", Component: Historial },
      { path: "perfil", Component: Perfil },
    ]
  }
]);
